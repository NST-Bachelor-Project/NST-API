# NST-API

## BUILD
docker build -t nst .

## RUN
docker run -it -p 80:80 nst